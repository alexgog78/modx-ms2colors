<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Colors.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Colors
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Colors
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'aadaf2ef655f48d617b77c8930a6415a',
      'native_key' => 'ms2colors',
      'filename' => 'modNamespace/64d9b56050d60e9b07207a7cffb1028f.vehicle',
      'namespace' => 'ms2colors',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1b7a994d42853a5494825b20966c11ed',
      'native_key' => '1b7a994d42853a5494825b20966c11ed',
      'filename' => 'xPDOFileVehicle/ece9d88b6abad105e933be80586e1ffa.vehicle',
      'namespace' => 'ms2colors',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e1413c952a16369c8798c5b903289845',
      'native_key' => 'e1413c952a16369c8798c5b903289845',
      'filename' => 'xPDOFileVehicle/c863a69a66d5c60dbd8e54ed64e480ac.vehicle',
      'namespace' => 'ms2colors',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6bc719b71b5acffc5c065fa65fbbe0b',
      'native_key' => 'ms2colors_file_source',
      'filename' => 'modSystemSetting/0a092cd8dc4412b6b33aad99a5ee0931.vehicle',
      'namespace' => 'ms2colors',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7e179a55824f733713944555935fe186',
      'native_key' => 1,
      'filename' => 'modCategory/6287bc4c5e545af729d07d72695b032d.vehicle',
      'namespace' => 'ms2colors',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '4688ced84ab85736dfd53650a93f206f',
      'native_key' => '4688ced84ab85736dfd53650a93f206f',
      'filename' => 'xPDOScriptVehicle/0c2fc87194ced1457938be43014fd002.vehicle',
      'namespace' => 'ms2colors',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'e3439498f9327da2a109030b8d9f4bb1',
      'native_key' => 'e3439498f9327da2a109030b8d9f4bb1',
      'filename' => 'xPDOScriptVehicle/d9ae53faab1fb8f74f4f47ed35c66ca7.vehicle',
      'namespace' => 'ms2colors',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'a832f2ffc168251652731a3c5325232a',
      'native_key' => 'a832f2ffc168251652731a3c5325232a',
      'filename' => 'xPDOScriptVehicle/2182e890aee388ff715446be30ec4b2a.vehicle',
      'namespace' => 'ms2colors',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '936fdee0cf1214a925f8b14791ac602f',
      'native_key' => '936fdee0cf1214a925f8b14791ac602f',
      'filename' => 'xPDOScriptVehicle/e78368c910da8a0993020fb26146b60d.vehicle',
      'namespace' => 'ms2colors',
    ),
  ),
);