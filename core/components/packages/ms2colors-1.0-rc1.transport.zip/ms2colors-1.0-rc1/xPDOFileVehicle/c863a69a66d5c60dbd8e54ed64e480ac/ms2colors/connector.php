<?php

define('PKG_NAME', 'ms2Colors');
define('PKG_NAME_LOWER', 'ms2colors');

require_once dirname(dirname(__FILE__)) . '/abstractmodule/connector.php';
