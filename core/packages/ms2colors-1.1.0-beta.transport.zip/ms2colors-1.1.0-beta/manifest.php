<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Colors.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Colors
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Colors
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'ms2Extend' => '>=1.1.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '155c733365df7799d1a53a78fe2e4513',
      'native_key' => 'ms2colors',
      'filename' => 'modNamespace/cb1e57c9fbb57a8a25c903247237dd68.vehicle',
      'namespace' => 'ms2colors',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd75eb6b8999cf7f788fd40f55721f13b',
      'native_key' => 'd75eb6b8999cf7f788fd40f55721f13b',
      'filename' => 'xPDOFileVehicle/6576e3064c7fe20927789dea7c04a3ff.vehicle',
      'namespace' => 'ms2colors',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c4cd8c86f38c90e5091d79122258c669',
      'native_key' => 'c4cd8c86f38c90e5091d79122258c669',
      'filename' => 'xPDOFileVehicle/a75bc4948d00e6fd45c0a66e31899d2b.vehicle',
      'namespace' => 'ms2colors',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '059ec61554ba42dd9b830ad4f23223e5',
      'native_key' => 'ms2colors_file_source',
      'filename' => 'modSystemSetting/a627a97ad5a7479fcf577e280f331a6b.vehicle',
      'namespace' => 'ms2colors',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '042745c04b8b94721057047eb801953f',
      'native_key' => NULL,
      'filename' => 'modMediaSource/e7ff0aca715adce144d3ac88df37c9ea.vehicle',
      'namespace' => 'ms2colors',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'c14b5945da8335e48a54e916dcf366f1',
      'native_key' => 0,
      'filename' => 'modChunk/05576dbeacf53b26d4904539b7e5ca9a.vehicle',
      'namespace' => 'ms2colors',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'c3e253b75a91ae7ac214c0646428aeda',
      'native_key' => 0,
      'filename' => 'modChunk/fda7333096a0067df466a5d8962b826a.vehicle',
      'namespace' => 'ms2colors',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '87f4b83aa336faa09bc8eb980d344782',
      'native_key' => 0,
      'filename' => 'modChunk/a80b71955527c471f4d1afd1760a4834.vehicle',
      'namespace' => 'ms2colors',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'b28bde141c91df0b06e80747f1024826',
      'native_key' => 0,
      'filename' => 'modChunk/6a4c0d98b5cccd80d303064191bbe641.vehicle',
      'namespace' => 'ms2colors',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => 'b636231d2b816dfbfaca450ced42c6d0',
      'native_key' => 0,
      'filename' => 'modSnippet/6f66914241ecbfe9ca8b3217b12547be.vehicle',
      'namespace' => 'ms2colors',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '686ba0743f688c1cec81296f1c5a6e7a',
      'native_key' => 0,
      'filename' => 'modPlugin/363f4651a29859d9316cadfde1bd1d86.vehicle',
      'namespace' => 'ms2colors',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '790674252c7345bbcc70ef3e13013fd9',
      'native_key' => 1,
      'filename' => 'modCategory/6338c098fcd013930476b2f7c32847ed.vehicle',
      'namespace' => 'ms2colors',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '7cca5d0c78230b72485ee44c94b0704d',
      'native_key' => '7cca5d0c78230b72485ee44c94b0704d',
      'filename' => 'xPDOScriptVehicle/97e5fed4e506847474dff65fd58af7f7.vehicle',
      'namespace' => 'ms2colors',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '17e66b87606523676566005921a4a961',
      'native_key' => '17e66b87606523676566005921a4a961',
      'filename' => 'xPDOScriptVehicle/d09ac21c0f2089a97439d2e51aa023f7.vehicle',
      'namespace' => 'ms2colors',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'cdd901115101a7c9ce289916a49cf8f9',
      'native_key' => 'cdd901115101a7c9ce289916a49cf8f9',
      'filename' => 'xPDOScriptVehicle/d995a5cb68a30824a660c89a8dc05cdc.vehicle',
      'namespace' => 'ms2colors',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'a4bce441080dd3725c3a23f5e21f8482',
      'native_key' => 'a4bce441080dd3725c3a23f5e21f8482',
      'filename' => 'xPDOScriptVehicle/8452b4b5c526d465324f45b2f2720b91.vehicle',
      'namespace' => 'ms2colors',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'b534634a483bcb5d140d551e51e1d47e',
      'native_key' => 'b534634a483bcb5d140d551e51e1d47e',
      'filename' => 'xPDOScriptVehicle/afc10cf059fb06252100e39bd066b12f.vehicle',
      'namespace' => 'ms2colors',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '1a6fb4735eb43230d1735f4b36b3078a',
      'native_key' => '1a6fb4735eb43230d1735f4b36b3078a',
      'filename' => 'xPDOScriptVehicle/595abc23fd526f121a2ea40a900eed2a.vehicle',
      'namespace' => 'ms2colors',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'f403e962de23af50bbdd36912bcd13f4',
      'native_key' => 'f403e962de23af50bbdd36912bcd13f4',
      'filename' => 'xPDOScriptVehicle/240d8a38b2fbe40eb89c7fbdb8a45c90.vehicle',
      'namespace' => 'ms2colors',
    ),
  ),
);