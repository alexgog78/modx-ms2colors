<?php

$prefix = 'ms2colors_property_';

$_lang[$prefix . 'snippet'] = 'Snippet, which will be called to output the results of work.';
