<?php

require_once(dirname(__DIR__) . '/ms2colorscolor.class.php');

class ms2colorsColor_mysql extends ms2colorsColor
{
}
