<?php

$xpdo_meta_map = [
    'abstractSimpleObject' => [
        0 => 'ms2colorsColor',
    ],
];
