<?php

$prefix = 'ms2colors_color_';

$_lang[$prefix . 'data'] = 'Data';
$_lang[$prefix . 'name'] = 'Name';
$_lang[$prefix . 'description'] = 'Description';
$_lang[$prefix . 'active'] = 'Active';
$_lang[$prefix . 'image'] = 'Image';
$_lang[$prefix . 'common'] = 'Common color';
$_lang[$prefix . 'collection'] = 'Collection color';
$_lang[$prefix . 'properties'] = 'Custom options';
$_lang[$prefix . 'property_key'] = 'Key';
$_lang[$prefix . 'property_value'] = 'Value';

$_lang['mse2_filter_ms_ms2colors_collection_id'] = 'Common color';
$_lang['mse2_filter_ms_ms2colors_common_id'] = 'Collection color';
