<?php

$prefix = 'ms2colors_property_';

$_lang[$prefix . 'snippet'] = 'Сниппет, который будет вызываться для вывода результатов работы.';
