<?php

$prefix = 'ms2colors_';

$_lang['ms2colors'] = 'ms2Colors';
$_lang[$prefix . 'desc'] = 'Цвета товаров miniShop2';

$_lang[$prefix . 'undefined'] = '<span class="icon icon-lock" style="font-size: 200%;"></span><br />Для начала сохраните объект';
$_lang[$prefix . 'indevelopment'] = '<span class="icon icon-cog" style="font-size: 200%;"></span><br />Раздел находится в разработке';
