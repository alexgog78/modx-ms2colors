<?php

$prefix = 'setting_ms2colors_';

$_lang[$prefix . 'file_source'] = 'Источник файлов по умолчанию';
$_lang[$prefix . 'file_source_desc'] = 'Источник файлов для изображений цветов по умолчанию.';
