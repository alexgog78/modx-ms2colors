'use strict';

Ext.apply(ms2Colors.component, {});
