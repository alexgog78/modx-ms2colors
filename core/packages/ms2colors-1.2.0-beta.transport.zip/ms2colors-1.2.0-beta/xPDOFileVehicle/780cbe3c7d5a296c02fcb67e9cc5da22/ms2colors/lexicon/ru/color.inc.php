<?php

$prefix = 'ms2colors_color_';

$_lang[$prefix . 'data'] = 'Данные';
$_lang[$prefix . 'name'] = 'Название';
$_lang[$prefix . 'description'] = 'Описание';
$_lang[$prefix . 'active'] = 'Активный';
$_lang[$prefix . 'image'] = 'Изображение';
$_lang[$prefix . 'common'] = 'Общий цвет';
$_lang[$prefix . 'collection'] = 'Цвет коллекции';
$_lang[$prefix . 'properties'] = 'Пользовательские опции';
$_lang[$prefix . 'property_key'] = 'Ключ';
$_lang[$prefix . 'property_value'] = 'Значение';

$_lang['mse2_filter_ms2colors_collection_id'] = 'Общий цвет';
$_lang['mse2_filter_ms2colors_common_id'] = 'Цвет коллекции';
