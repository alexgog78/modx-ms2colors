<?php

$prefix = 'setting_ms2colors_';

$_lang[$prefix . 'file_source'] = 'Default media source';
$_lang[$prefix . 'file_source_desc'] = 'Default media source for color image.';
