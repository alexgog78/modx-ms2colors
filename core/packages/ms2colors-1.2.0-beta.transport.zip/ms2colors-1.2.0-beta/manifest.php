<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Colors.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Colors
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Colors
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
      'abstractModule' => '>=1.1.0',
      'ms2Extend' => '>=1.2.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '767976c88dad33372a9ac0a80d1a5d2a',
      'native_key' => 'ms2colors',
      'filename' => 'modNamespace/36b6d4e90e9f8ccad7f9a0f381ecbabb.vehicle',
      'namespace' => 'ms2colors',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '6ce9a8e8cf4fc983391fec69aee14774',
      'native_key' => '6ce9a8e8cf4fc983391fec69aee14774',
      'filename' => 'xPDOFileVehicle/0fbce511242f822981e5703e1e6e2ea0.vehicle',
      'namespace' => 'ms2colors',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4d830e51004a94521cba3e51f1cc6c2f',
      'native_key' => '4d830e51004a94521cba3e51f1cc6c2f',
      'filename' => 'xPDOFileVehicle/dfc48a49c65a966ef39bae2d4e02bcf5.vehicle',
      'namespace' => 'ms2colors',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffdd1fa8275f12c84a261ae9f81ca72f',
      'native_key' => 'ms2colors_file_source',
      'filename' => 'modSystemSetting/1d5e277d64edaabb0bd2640d4079cdbf.vehicle',
      'namespace' => 'ms2colors',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'e9d5fed9ff115bf645f000a73232fc67',
      'native_key' => 0,
      'filename' => 'modChunk/538f1e652eb66481a3f0fd0034db6caf.vehicle',
      'namespace' => 'ms2colors',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '6db98862002fff58c369b50692a54369',
      'native_key' => 0,
      'filename' => 'modChunk/46460ef1b758b51d52b98d04a9857bae.vehicle',
      'namespace' => 'ms2colors',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '674243c21af67bfceab6505fc3268aea',
      'native_key' => 0,
      'filename' => 'modChunk/78efc3d96825ce5d7c71b716500f9faf.vehicle',
      'namespace' => 'ms2colors',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '170a5c2b554b9658075595372b83e81a',
      'native_key' => 0,
      'filename' => 'modChunk/78305dfc80e10b8ebfe7319ff443b077.vehicle',
      'namespace' => 'ms2colors',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '3a69cb99434c4ecd4326b5960fbe93f6',
      'native_key' => 0,
      'filename' => 'modSnippet/82c8fbe11708b23ff0f4a2dfa4cc6c2b.vehicle',
      'namespace' => 'ms2colors',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'c8a4f4642c91910b2ab30338c0c582a5',
      'native_key' => 0,
      'filename' => 'modPlugin/e03771df63cc0184c949d35961dbff01.vehicle',
      'namespace' => 'ms2colors',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '5ef4ec04159519abe798fffe3c4af5a8',
      'native_key' => NULL,
      'filename' => 'modMediaSource/e037d0e6fd770cab79a3b7fb99bba71c.vehicle',
      'namespace' => 'ms2colors',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'aa4260a2d3028bf37a7af50d08954b49',
      'native_key' => 1,
      'filename' => 'modCategory/708abde5e6dd8553e54fa2fb901008d6.vehicle',
      'namespace' => 'ms2colors',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '4fcb31e293d08b8835ef430761e1bc5c',
      'native_key' => '4fcb31e293d08b8835ef430761e1bc5c',
      'filename' => 'xPDOScriptVehicle/54f20132042b6a8a3bbd63dafe1e10dd.vehicle',
      'namespace' => 'ms2colors',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '7519fd246d66c9de8e2e060e55082204',
      'native_key' => '7519fd246d66c9de8e2e060e55082204',
      'filename' => 'xPDOScriptVehicle/662d539cd8f900c13ea963915140bacf.vehicle',
      'namespace' => 'ms2colors',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '58c13724f0fb4b8307b476e14353b643',
      'native_key' => '58c13724f0fb4b8307b476e14353b643',
      'filename' => 'xPDOScriptVehicle/72ac06302f6511f500e1e15059e199ba.vehicle',
      'namespace' => 'ms2colors',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'c5dee7501739364ef5b0159f2b6d756c',
      'native_key' => 'c5dee7501739364ef5b0159f2b6d756c',
      'filename' => 'xPDOScriptVehicle/74bc79610ee54a7c35703ad2e26e46c3.vehicle',
      'namespace' => 'ms2colors',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '07e8c5546dd2b3dedfc220a71d62be9b',
      'native_key' => '07e8c5546dd2b3dedfc220a71d62be9b',
      'filename' => 'xPDOScriptVehicle/a6395ea556883944a46b0fcd73b8d370.vehicle',
      'namespace' => 'ms2colors',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '7c31ecd6626682738088e567684fa10d',
      'native_key' => '7c31ecd6626682738088e567684fa10d',
      'filename' => 'xPDOScriptVehicle/26695ff96ac55c085c7168b626364995.vehicle',
      'namespace' => 'ms2colors',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'c6363513fa6065eba43d86a82c84d216',
      'native_key' => 'c6363513fa6065eba43d86a82c84d216',
      'filename' => 'xPDOScriptVehicle/1419a8de84874d40fd0e036e924e5ffe.vehicle',
      'namespace' => 'ms2colors',
    ),
  ),
);