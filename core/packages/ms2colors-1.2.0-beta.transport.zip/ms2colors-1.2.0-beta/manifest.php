<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Colors.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Colors
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Colors
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
      'abstractModule' => '>=1.1.0',
      'ms2Extend' => '>=1.2.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '259b8305499af0be7844c527ef300b83',
      'native_key' => 'ms2colors',
      'filename' => 'modNamespace/391f75366b07fdb7a38a3dee81b115ae.vehicle',
      'namespace' => 'ms2colors',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4cb039fc8d503d60af8eab00c355f492',
      'native_key' => '4cb039fc8d503d60af8eab00c355f492',
      'filename' => 'xPDOFileVehicle/780cbe3c7d5a296c02fcb67e9cc5da22.vehicle',
      'namespace' => 'ms2colors',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ea04d318bc6bf52ca03cbb671158ed9c',
      'native_key' => 'ea04d318bc6bf52ca03cbb671158ed9c',
      'filename' => 'xPDOFileVehicle/4c6a0818d939301af6a33ba6256f2bea.vehicle',
      'namespace' => 'ms2colors',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e59513820aa303feae5d9435e22cee8',
      'native_key' => 'ms2colors_file_source',
      'filename' => 'modSystemSetting/af1dc04eeee460c29aeb9de2938a72ef.vehicle',
      'namespace' => 'ms2colors',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '1e6bea47ff6862ff27283b3848843c1a',
      'native_key' => 0,
      'filename' => 'modChunk/28e4ae8e60517b752db93728d83ea2b0.vehicle',
      'namespace' => 'ms2colors',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '3e7e28275059c6414db61306dda97e6e',
      'native_key' => 0,
      'filename' => 'modChunk/0c6976f6c24d9110db275cc9bc82358f.vehicle',
      'namespace' => 'ms2colors',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'd22ec4837a46c7bebc7313c0755295d8',
      'native_key' => 0,
      'filename' => 'modChunk/2f48200dd0bba126c0a2880a1c847530.vehicle',
      'namespace' => 'ms2colors',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'b3c3c541221a38c3fe2ad97a37ae19f3',
      'native_key' => 0,
      'filename' => 'modChunk/2999a79f883e76cad0e2cdf4ebb89a86.vehicle',
      'namespace' => 'ms2colors',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => 'df1991b19f4e7052282a4bf309b67f0a',
      'native_key' => 0,
      'filename' => 'modSnippet/7ab2d43b6e8a2fd0347c410cf58e516a.vehicle',
      'namespace' => 'ms2colors',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'b49cd1c2408edf7723ff0d12b50f963e',
      'native_key' => 0,
      'filename' => 'modPlugin/5479e463b23484a2531a5aed25f53cdd.vehicle',
      'namespace' => 'ms2colors',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '79f9101338d01ccdd1ebe07237f5f9d6',
      'native_key' => NULL,
      'filename' => 'modMediaSource/653932e5ff86cf5fbae1166e92926faf.vehicle',
      'namespace' => 'ms2colors',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0377f4b6f4883e3e90169991b950bcd4',
      'native_key' => 1,
      'filename' => 'modCategory/3de98c6c8b97bf2a76e74b60b87ab994.vehicle',
      'namespace' => 'ms2colors',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'faa980eb736dc9fb1b908c0fedd09016',
      'native_key' => 'faa980eb736dc9fb1b908c0fedd09016',
      'filename' => 'xPDOScriptVehicle/d5a6cfa71a751351a85c3dcb0910c101.vehicle',
      'namespace' => 'ms2colors',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '6ec6cdb1d6cd7cc739f2895c20e9c3d3',
      'native_key' => '6ec6cdb1d6cd7cc739f2895c20e9c3d3',
      'filename' => 'xPDOScriptVehicle/9336d1dea9a0a33a524b7dd8ed820537.vehicle',
      'namespace' => 'ms2colors',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '39878f5d32d139e6d2ca7f0a2e85da84',
      'native_key' => '39878f5d32d139e6d2ca7f0a2e85da84',
      'filename' => 'xPDOScriptVehicle/6609127306b49ed65dda47467ae85f99.vehicle',
      'namespace' => 'ms2colors',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '9819766cbbfa5c1b4cf19c178d60b738',
      'native_key' => '9819766cbbfa5c1b4cf19c178d60b738',
      'filename' => 'xPDOScriptVehicle/d2656fd9f93942f32f3c626e7582b674.vehicle',
      'namespace' => 'ms2colors',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'ef8761e7fed8bdeb85ab8fe3960b77ae',
      'native_key' => 'ef8761e7fed8bdeb85ab8fe3960b77ae',
      'filename' => 'xPDOScriptVehicle/c9d24fd072fc43e289506f87f3116449.vehicle',
      'namespace' => 'ms2colors',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '559089962007a9f6f22f0ff50eb984e6',
      'native_key' => '559089962007a9f6f22f0ff50eb984e6',
      'filename' => 'xPDOScriptVehicle/f9ee8735e6b4fbcfb1798797fec075eb.vehicle',
      'namespace' => 'ms2colors',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '1501eaa1a711c32619e17eefe0012e91',
      'native_key' => '1501eaa1a711c32619e17eefe0012e91',
      'filename' => 'xPDOScriptVehicle/d3630e45d94d2a0b8c742465c5e510af.vehicle',
      'namespace' => 'ms2colors',
    ),
  ),
);