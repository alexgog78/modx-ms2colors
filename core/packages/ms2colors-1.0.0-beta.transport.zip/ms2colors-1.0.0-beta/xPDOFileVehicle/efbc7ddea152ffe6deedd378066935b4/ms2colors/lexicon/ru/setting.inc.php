<?php

$prefix = 'ms2colors';

$_lang['setting_' . $prefix . '_file_source'] = 'Источник файлов по умолчанию';
$_lang['setting_' . $prefix . '_file_source_desc'] = 'Источник файлов для изображений цветов по умолчанию.';
