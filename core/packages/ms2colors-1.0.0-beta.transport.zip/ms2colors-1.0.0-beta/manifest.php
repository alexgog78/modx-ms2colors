<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Colors.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Colors
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Colors
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '01778af289bec57806e59840b536e834',
      'native_key' => 'ms2colors',
      'filename' => 'modNamespace/58530cb0119c8b8f7227da0e64b3bf5a.vehicle',
      'namespace' => 'ms2colors',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'fddd38f24c1a4fe63772741675492d7a',
      'native_key' => 'fddd38f24c1a4fe63772741675492d7a',
      'filename' => 'xPDOFileVehicle/efbc7ddea152ffe6deedd378066935b4.vehicle',
      'namespace' => 'ms2colors',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '187cc5d4a5de72ffb03d574aafe80d39',
      'native_key' => '187cc5d4a5de72ffb03d574aafe80d39',
      'filename' => 'xPDOFileVehicle/51a1d1d31d7edf70f716aadf775ffe6d.vehicle',
      'namespace' => 'ms2colors',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80c8edd689763b011eee67e2fc598f14',
      'native_key' => 'ms2colors_file_source',
      'filename' => 'modSystemSetting/08802db0c16797cc8f77307d820c1f6f.vehicle',
      'namespace' => 'ms2colors',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '953fe4b1305500084b71d2c8cc1cb18d',
      'native_key' => 1,
      'filename' => 'modCategory/ca4e0f61e64353a9b97b9c00f33d7ba5.vehicle',
      'namespace' => 'ms2colors',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '036e9960bd48e85cfbf4425d756fdd15',
      'native_key' => '036e9960bd48e85cfbf4425d756fdd15',
      'filename' => 'xPDOScriptVehicle/7c80a743e87766cb498775706cd00caa.vehicle',
      'namespace' => 'ms2colors',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'b565a382f260cd9e1640f22fb1de3d82',
      'native_key' => 'b565a382f260cd9e1640f22fb1de3d82',
      'filename' => 'xPDOScriptVehicle/8bcbac280831c0a64c94659540633c9f.vehicle',
      'namespace' => 'ms2colors',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '0b2d86fc82e61813f4885941edbab0ce',
      'native_key' => '0b2d86fc82e61813f4885941edbab0ce',
      'filename' => 'xPDOScriptVehicle/ea91ef63dea3f281bb56e053d577fd36.vehicle',
      'namespace' => 'ms2colors',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '023e6763c70719f574d982ad2acfdec5',
      'native_key' => '023e6763c70719f574d982ad2acfdec5',
      'filename' => 'xPDOScriptVehicle/6b0f48a0f4a64952715c89d7c989f267.vehicle',
      'namespace' => 'ms2colors',
    ),
  ),
);